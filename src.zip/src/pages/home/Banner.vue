<template>
	<div class = "banner">
		asdbfsadfhjahdjkflhsadjklfhalsdkjfhalsjk
	</div>
</template>
<script >
	export default {

	}
</script>

<style >
	.banner{ 
		background:red;
	 }
</style>