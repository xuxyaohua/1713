<template>
  <div id ="app">
      <router-view/>
  </div>
</template>

<script>
	  export default {
	    name: 'app'
	  }
</script>

<style>
  @import "./reset.css";
  @import "./iconfont/iconfont.css"
/*  @import "../../node_modules/swiper/dist/css/swiper.css";*/
</style>